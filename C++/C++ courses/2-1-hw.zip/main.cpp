#include <iostream>
using namespace std;

int main()
{
    /*Sa se afiseze primele n numere prime, 
    unde n se citeste de la tastatura. De exemplu, 
    pentru n = 7, se afiseaza 2, 3, 5, 7, 11, 13, 17. */
    
    return 0;
}