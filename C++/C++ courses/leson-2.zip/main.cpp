#include <iostream>
using namespace std;

int main()
{
    /*data types are what the computer understands
    when we want to do operations with variables, numbers and characters*/
    
    //i think you know damn well what characters are
    
    int a=3; //u know this
    float b=2.5; //yeah
    double c=8.789; //bigger floats that take up more space
    
    /*variables are letters, groups of letters and
    letters with other characters*/
    
    char d='d'; //just one character lol
    
    //cout << d; //dis how you show variabel
    
    cout<<a<<' '<<b<<' '<<c<<' '<<d;
    
    //cin in used for reading obviously
    
    cout<<endl; //end line, just goes on the next line
    cin>>a;
    cout<<a;
    
    return 0;
}