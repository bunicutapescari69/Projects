#include <iostream>
using namespace std;

int main(){
    cout<<"helo woerl";
    /*cout is basically output. now its also in namespace std. without it
    it would be std::cout<<"Hello World"; */
    //another way of commenting could be this
    return 0;
    //this simply ends the program
}