#include <iostream>
using namespace std;

int main()
{
    //write a prog that shows the 
    //multiplying table of n
    double n; cout<<"Insert number:"; cin>>n;
    
    for(int i=1; i<=10; i++) {
        for(int j=0; j<=0; j++) {
            cout<<n<<"x"<<i<<"="<<n*i;
        }
        cout<<endl;
    }

    return 0;
}