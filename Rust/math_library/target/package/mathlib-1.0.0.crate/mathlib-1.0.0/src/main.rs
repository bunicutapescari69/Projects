use mathlib::rem;
fn main() {
    let result = rem(5.3, 2.0);
    println!("The remainder is: {}", result);
}
